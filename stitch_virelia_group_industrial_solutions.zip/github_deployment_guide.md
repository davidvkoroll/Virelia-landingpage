# GitHub Deployment Guide für Virelia Group Landingpage

Diese Dokumentation hilft Ihnen dabei, den Code Ihrer Landingpage auf GitHub zu hosten und via GitHub Pages kostenlos zu veröffentlichen.

## 1. Vorbereitung
Sie benötigen die folgenden Dateien aus diesem Projekt:
- `index.html` (Die Hauptdatei mit Ihrem Design)
- Bilder (Diese werden von Stitch-Servern geladen, Sie müssen sie nicht lokal speichern, solange Sie die Pfade im Code nicht ändern)

## 2. GitHub Repository erstellen
1. Melden Sie sich bei [GitHub](https://github.com) an.
2. Klicken Sie auf das **+** oben rechts und wählen Sie **New repository**.
3. Geben Sie dem Repository einen Namen (z. B. `virelia-landingpage`).
4. Stellen Sie sicher, dass es auf **Public** gesetzt ist.
5. Klicken Sie auf **Create repository**.

## 3. Dateien hochladen
1. Klicken Sie in Ihrem neuen Repository auf **uploading an existing file**.
2. Ziehen Sie die `index.html` Datei (die Sie über den Code-Export in Stitch erhalten) in das Fenster.
3. Klicken Sie auf **Commit changes**.

## 4. GitHub Pages aktivieren
1. Gehen Sie in Ihrem Repository auf den Reiter **Settings**.
2. Klicken Sie in der linken Seitenleiste auf **Pages**.
3. Wählen Sie unter "Branch" den Branch `main` (oder `master`) und den Ordner `/ (root)`.
4. Klicken Sie auf **Save**.

Nach wenigen Minuten ist Ihre Seite unter `https://[ihr-benutzername].github.io/virelia-landingpage/` erreichbar.

## 5. Eigene Domain verknüpfen
Wenn Sie `virelia-group.com` nutzen möchten:
1. Tragen Sie die Domain unter **Custom domain** in den GitHub Pages Einstellungen ein.
2. Sie müssen bei Ihrem Domain-Anbieter (z. B. IONOS) die DNS-Einstellungen (A-Records) auf die IP-Adressen von GitHub verweisen. Eine detaillierte Anleitung finden Sie in der GitHub Dokumentation.