---
name: Precision Infrastructure
colors:
  surface: '#f9f9ff'
  surface-dim: '#cfdbf1'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff3ff'
  surface-container: '#e6eeff'
  surface-container-high: '#dde9ff'
  surface-container-highest: '#d7e3fa'
  on-surface: '#101c2c'
  on-surface-variant: '#414844'
  inverse-surface: '#253142'
  inverse-on-surface: '#ebf1ff'
  outline: '#717973'
  outline-variant: '#c1c8c2'
  surface-tint: '#3f6653'
  primary: '#012d1d'
  on-primary: '#ffffff'
  primary-container: '#1b4332'
  on-primary-container: '#86af99'
  inverse-primary: '#a5d0b9'
  secondary: '#5b5d74'
  on-secondary: '#ffffff'
  secondary-container: '#ddddf9'
  on-secondary-container: '#5f6178'
  tertiary: '#1f2825'
  on-tertiary: '#ffffff'
  tertiary-container: '#353e3a'
  on-tertiary-container: '#9fa9a3'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#c1ecd4'
  primary-fixed-dim: '#a5d0b9'
  on-primary-fixed: '#002114'
  on-primary-fixed-variant: '#274e3d'
  secondary-fixed: '#e0e0fc'
  secondary-fixed-dim: '#c4c4df'
  on-secondary-fixed: '#181a2e'
  on-secondary-fixed-variant: '#43455b'
  tertiary-fixed: '#dbe5df'
  tertiary-fixed-dim: '#bfc9c3'
  on-tertiary-fixed: '#151d1a'
  on-tertiary-fixed-variant: '#3f4945'
  background: '#f9f9ff'
  on-background: '#101c2c'
  surface-variant: '#d7e3fa'
typography:
  display-lg:
    fontFamily: Montserrat
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: 0.02em
  headline-lg:
    fontFamily: Montserrat
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: 0.05em
  headline-md:
    fontFamily: Montserrat
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: 0.05em
  headline-sm:
    fontFamily: Montserrat
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: 0.05em
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.08em
  headline-lg-mobile:
    fontFamily: Montserrat
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 64px
  container-max: 1280px
---

## Brand & Style
The design system for Virelia Group is rooted in **Corporate Industrialism**. It prioritizes technical authority, medical-grade precision, and logistical efficiency over lifestyle aesthetics. The brand personality is clinical, robust, and institutional, positioning the company as a leader in large-scale infrastructure rather than consumer retail.

The visual style utilizes a **Corporate Modern** approach with **Minimalist** execution. It favors high-density information layouts balanced by expansive whitespace to ensure clarity in complex project development data. The aesthetic should feel like a premium laboratory or a high-tech manufacturing dashboard: clean, structured, and unapologetically professional.

## Colors
The palette is anchored by **Deep Botanical Green**, representing the core biological industry but desaturated to feel professional and established. **Technical Anthracite** provides the structural backbone for typography and UI borders, ensuring high contrast and legibility.

- **Primary (Botanical Green):** Reserved for primary actions, brand headers, and signifying growth or operational status.
- **Secondary (Anthracite):** Used for navigation backgrounds, text, and technical UI elements.
- **Accents (Silver/Mint):** Utilized for data visualization, subtle section separators, and hover states to maintain a "clean room" feel.
- **Backgrounds:** Pure white is the default to maximize whitespace. A very light gray (`#F8F9FA`) is used to differentiate technical specifications or data tables from general content.

## Typography
Typography is a critical tool for conveying "Industrial Precision." 

- **Headlines (Montserrat):** Must be rendered in **All-Caps** for levels `headline-lg` through `headline-sm` to evoke blueprint headers and industrial signage. The increased letter spacing ensures readability in large formats.
- **Body & Labels (Inter):** Chosen for its exceptional legibility in technical documents. It should remain in sentence case.
- **Data Display:** For numerical values in tables or laboratory results, use `label-md` with a semi-bold weight to ensure data stands out from descriptive text.

## Layout & Spacing
The layout follows a **Fixed Grid** philosophy on desktop to maintain a sense of controlled engineering. 

- **Grid:** A 12-column grid is used for desktop (1280px max-width) with 24px gutters.
- **Modular Rhythm:** All spacing should be multiples of 4px. Use 32px (8 units) or 48px (12 units) for section vertical spacing to maintain high levels of whitespace.
- **Mobile Adaptation:** On mobile, the layout collapses to a single column with 16px side margins. Grid-heavy technical data should shift to horizontally scrollable cards or simplified lists to maintain utility.

## Elevation & Depth
To maintain a professional, "flat" industrial feel, this design system avoids heavy shadows. Depth is communicated through **Low-Contrast Outlines** and **Tonal Layers**.

- **Surfaces:** Use 1px solid borders in Anthracite (at 10-15% opacity) to define cards and containers.
- **Stacking:** For modals or pop-overs, use a very tight, crisp shadow (4px blur, 10% opacity) to provide just enough separation without looking "soft" or "cloud-like."
- **Overlays:** Technical overlays (like tooltips) should use the Secondary (Anthracite) background with white text to stand out against the white/light-gray base.

## Shapes
Shapes are **Soft (0.25rem)** to suggest a "finished" industrial product—like machined metal or molded medical equipment. 

- **Standard Elements:** Buttons, input fields, and tags use the base 4px radius.
- **Containers:** Larger cards may use `rounded-lg` (8px) to soften the large surface area, but should never reach "pill" or "circular" territory, as sharp geometry is more associated with technical reliability.

## Components
- **Buttons:** Primary buttons use the Botanical Green background with White text, Montserrat bold all-caps. Secondary buttons use an Anthracite outline.
- **Input Fields:** Use a rigid rectangular structure with a subtle 1px border. Focus states use a Botanical Green 2px border—no "glow" effects. Labels should be small, all-caps, and placed above the field.
- **Chips/Status:** Use rectangular chips with 2px radius. Status colors: Mint (Operational), Silver (Idle/Pending), and Charcoal (Inactive).
- **Cards:** Clean white backgrounds with light gray borders. Avoid shadows. Group related technical data using thin horizontal dividers.
- **Data Tables:** Highly structured with Anthracite headers. Alternate row striping using the Light Gray background for readability in long-form infrastructure reports.
- **Progress Indicators:** Use thin, linear bars rather than circular loaders to maintain the architectural/industrial aesthetic.